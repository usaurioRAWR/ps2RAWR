#include "launchelf.h"

enum
{
	DEF_TIMEOUT = 10,
	DEF_FILENAME = TRUE,
	DEF_COLOR1 = ITO_RGBA(30,30,50,0),
	DEF_COLOR2 = ITO_RGBA(85,85,95,0),
	DEF_COLOR3 = ITO_RGBA(160,160,160,0),
	DEF_COLOR4 = ITO_RGBA(255,255,255,0),
	DEF_SCREEN_X = 128,
	DEF_SCREEN_Y = 30,
	DEF_DISCCONTROL = TRUE,
	DEF_INTERLACE = FALSE,
	
	DEFAULT=0,
	TIMEOUT=12,
	DISCCONTROL,
	FILENAME,
	SCREEN,
	OK,
	CANCEL
};

SETTING *setting, *tmpsetting;

////////////////////////////////////////////////////////////////////////
// �������[�J�[�h�̏�Ԃ��`�F�b�N����B
// �߂�l�͗L���ȃ������[�J�[�h�X���b�g�̔ԍ��B
// �������[�J�[�h���}�����Ă��Ȃ��ꍇ��-11��Ԃ��B
int CheckMC(void)
{
	int ret;
	
	mcGetInfo(0, 0, NULL, NULL, NULL);
	mcSync(0, NULL, &ret);

	if( -1 == ret || 0 == ret) return 0;

	mcGetInfo(0, 0, NULL, NULL, NULL);
	mcSync(0, NULL, &ret);

	if( -1 == ret || 0 == ret ) return 1;

	return -11;
}

////////////////////////////////////////////////////////////////////////
// LAUNCHELF.CNF �ɐݒ��ۑ�����
void saveConfig(char *mainMsg)
{
	int i, ret, fd, size;
	const char LF[3]={0x0D, 0x0A, 0};
	char c[MAX_PATH], tmp[22][MAX_PATH];
	char* p;
	
	// �ݒ���������Ɋi�[
	for(i=0; i<12; i++)
		strcpy(tmp[i], setting->dirElf[i]);
	sprintf(tmp[12], "%d", setting->timeout);
	sprintf(tmp[13], "%d", setting->filename);
	for(i=0; i<4; i++)
		sprintf(tmp[14+i], "%lu", setting->color[i]);
	sprintf(tmp[18], "%d", setting->screen_x);
	sprintf(tmp[19], "%d", setting->screen_y);
	sprintf(tmp[20], "%d", setting->discControl);
	sprintf(tmp[21], "%d", setting->interlace);
	
	p = (char*)malloc(sizeof(SETTING));
	p[0]=0;
	size=0;
	for(i=0; i<22; i++){
		strcpy(c, tmp[i]);
		strcat(c, LF);
		strcpy(p+size, c);
		size += strlen(c);
	}
	// LaunchELF�̃f�B���N�g����CNF����������LaunchELF�̃f�B���N�g���ɃZ�[�u
	strcpy(c, LaunchElfDir);
	strcat(c, "LAUNCHELF.CNF");
	if((fd=fioOpen(c, O_RDONLY)) >= 0)
		fioClose(fd);
	else{
		if(!strncmp(LaunchElfDir, "mc", 2))
			sprintf(c, "mc%d:/SYS-CONF", LaunchElfDir[2]-'0');
		else
			sprintf(c, "mc%d:/SYS-CONF", CheckMC());
		// SYS-CONF����������SYS-CONF�ɃZ�[�u
		if((fd=fioDopen(c)) >= 0){
			fioDclose(fd);
			strcat(c, "/LAUNCHELF.CNF");
		// SYS-CONF���Ȃ�������LaunchELF�̃f�B���N�g���ɃZ�[�u
		}else{
			strcpy(c, LaunchElfDir);
			strcat(c, "LAUNCHELF.CNF");
		}
	}
	strcpy(mainMsg,"Save Failed");
	// ��������
	if((fd=fioOpen(c,O_CREAT|O_WRONLY|O_TRUNC)) < 0){
		return;
	}
	ret = fioWrite(fd,p,size);
	if(ret==size) sprintf(mainMsg, "Save Config (%s)", c);
	fioClose(fd);
	free(p);
}

////////////////////////////////////////////////////////////////////////
// LAUNCHELF.CNF ����ݒ��ǂݍ���
void loadConfig(char *mainMsg)
{
	int i, j, k, fd, len, mcport;
	size_t size;
	char path[MAX_PATH], tmp[22][MAX_PATH], *p;
	
	setting = (SETTING*)malloc(sizeof(SETTING));
	// LaunchELF�����s���ꂽ�p�X����ݒ�t�@�C�����J��
	sprintf(path, "%s%s", LaunchElfDir, "LAUNCHELF.CNF");
	if(!strncmp(path, "cdrom", 5)) strcat(path, ";1");
	fd = fioOpen(path, O_RDONLY);
	// �J���Ȃ�������ASYS-CONF�̐ݒ�t�@�C�����J��
	if(fd<0) {
		if(!strncmp(LaunchElfDir, "mc", 2))
			mcport = LaunchElfDir[2]-'0';
		else
			mcport = CheckMC();
		if(mcport==1 || mcport==0){
			sprintf(path, "mc%d:/SYS-CONF/LAUNCHELF.CNF", mcport);
			fd = fioOpen(path, O_RDONLY);
		}
	}
	// �ǂ̃t�@�C�����J���Ȃ������ꍇ�A�ݒ������������
	if(fd<0) {
		for(i=0; i<12; i++)
			setting->dirElf[i][0] = 0;
		setting->timeout = DEF_TIMEOUT;
		setting->filename = DEF_FILENAME;
		setting->color[0] = DEF_COLOR1;
		setting->color[1] = DEF_COLOR2;
		setting->color[2] = DEF_COLOR3;
		setting->color[3] = DEF_COLOR4;
		setting->screen_x = DEF_SCREEN_X;
		setting->screen_y = DEF_SCREEN_Y;
		setting->discControl = DEF_DISCCONTROL;
		setting->interlace = DEF_INTERLACE;
		mainMsg[0] = 0;
	} else {
		// �ݒ�t�@�C�����������ɓǂݍ���
		size = fioLseek(fd, 0, SEEK_END);
		printf("size=%d\n", size);
		fioLseek(fd, 0, SEEK_SET);
		p = (char*)malloc(sizeof(size));
		fioRead(fd, p, size);
		fioClose(fd);
		
		// �v22�s�̃e�L�X�g��ǂݍ���
		// 12�s�ڂ܂ł̓{�^���Z�b�e�B���O
		// 13�s�ڂ� TIMEOUT �l
		// 14�s�ڂ� PRINT ONLY FILENAME �̐ݒ�l
		// 15�s�ڂ̓J���[1
		// 16�s�ڂ̓J���[2
		// 17�s�ڂ̓J���[3
		// 18�s�ڂ̓J���[4
		// 19�s�ڂ̓X�N���[��X
		// 20�s�ڂ̓X�N���[��Y
		// 21�s�ڂ̓f�B�X�N�R���g���[��
		// 22�s�ڂ̓C���^�[���[�X
		for(i=j=k=0; i<size; i++) {
			if(p[i]==0x0D && p[i+1]==0x0A) {
				if(i-k<MAX_PATH) {
					p[i]=0;
					strcpy(tmp[j++], &p[k]);
				} else
					break;
				if(j>=22)
					break;
				k=i+2;
			}
		}
		while(j<22)
			tmp[j++][0] = 0;
		// �{�^���Z�b�e�B���O
		for(i=0; i<12; i++) {
			// v3.01�ȑO�̃o�[�W�����Ƃ̏�ʌ݊�
			if(tmp[i][0] == '/')
				sprintf(setting->dirElf[i], "mc:%s", tmp[i]);
			else
				strcpy(setting->dirElf[i], tmp[i]);
		}
		// TIMEOUT�l�̐ݒ�
		if(tmp[12][0]) {
			setting->timeout = 0;
			len = strlen(tmp[12]);
			i = 1;
			while(len-- != 0) {
				setting->timeout += (tmp[12][len]-'0') * i;
				i *= 10;
			}
		} else
			setting->timeout = DEF_TIMEOUT;
		// PRINT ONLY FILENAME �̐ݒ�
		if(tmp[13][0])
			setting->filename = tmp[13][0]-'0';
		else
			setting->filename = DEF_FILENAME;
		// �J���[1����4�̐ݒ�
		if(tmp[14][0]) {
			for(i=0; i<4; i++) {
				setting->color[i] = 0;
				len = strlen(tmp[14+i]);
				j = 1;
				while(len-- != 0) {
					setting->color[i] += (tmp[14+i][len]-'0') * j;
					j *= 10;
				}
			}
		} else {
			setting->color[0] = DEF_COLOR1;
			setting->color[1] = DEF_COLOR2;
			setting->color[2] = DEF_COLOR3;
			setting->color[3] = DEF_COLOR4;
		}
		// �X�N���[��X�̐ݒ�
		if(tmp[18][0]) {
			setting->screen_x = 0;
			j = strlen(tmp[18]);
			for(i=1; j; i*=10)
				setting->screen_x += (tmp[18][--j]-'0')*i;
		} else
			setting->screen_x = DEF_SCREEN_X;
		// �X�N���[��Y�̐ݒ�
		if(tmp[19][0]) {
			setting->screen_y = 0;
			j = strlen(tmp[19]);
			for(i=1; j; i*=10)
				setting->screen_y += (tmp[19][--j]-'0')*i;
		} else
			setting->screen_y = DEF_SCREEN_Y;
		// �f�B�X�N�R���g���[���̐ݒ�
		if(tmp[20][0])
			setting->discControl = tmp[20][0]-'0';
		else
			setting->discControl = DEF_DISCCONTROL;
		// �C���^�[���[�X�̐ݒ�
		if(tmp[21][0])
			setting->interlace = tmp[21][0]-'0';
		else
			setting->interlace = DEF_INTERLACE;
		
		free(p);
		sprintf(mainMsg, "Load Config (%s)", path);
	}
	return;
}

////////////////////////////////////////////////////////////////////////
// �X�N���[���Z�b�e�B���O���
void setColor(void)
{
	int i;
	int s;
	int x, y;
	uint64 rgb[4][3];
	char c[MAX_PATH];
	
	for(i=0; i<4; i++) {
		rgb[i][0] = setting->color[i] & 0xFF;
		rgb[i][1] = setting->color[i] >> 8 & 0xFF;
		rgb[i][2] = setting->color[i] >> 16 & 0xFF;
	}
	
	s=0;
	while(1)
	{
		// ����
		waitPadReady(0, 0);
		if(readpad())
		{
			if(new_pad & PAD_UP)
			{
				if(s!=0)
					s--;
				else
					s=16;
			}
			else if(new_pad & PAD_DOWN)
			{
				if(s!=16)
					s++;
				else
					s=0;
			}
			else if(new_pad & PAD_LEFT)
			{
				if(s>=15) s=14;
				else if(s>=14) s=12;
				else if(s>=12) s=9;
				else if(s>=9) s=6;
				else if(s>=6) s=3;
				else if(s>=3) s=0;
			}
			else if(new_pad & PAD_RIGHT)
			{
				if(s>=14) s=15;
				else if(s>=12) s=14;
				else if(s>=9) s=12;
				else if(s>=6) s=9;
				else if(s>=3) s=6;
				else s=3;
			}
			else if(new_pad & PAD_CROSS)
			{
				if(s<12) {
					if(rgb[s/3][s%3] > 0) {
						rgb[s/3][s%3]--;
						setting->color[s/3] = 
							ITO_RGBA(rgb[s/3][0], rgb[s/3][1], rgb[s/3][2], 0);
						if(s/3 == 0) itoSetBgColor(setting->color[0]);
					}
				} else if(s==12) {
					if(setting->screen_x > 0) {
						setting->screen_x--;
						screen_env.screen.x = setting->screen_x;
						itoSetScreenPos(setting->screen_x, setting->screen_y);
					}
				} else if(s==13) {
					if(setting->screen_y > 0) {
						setting->screen_y--;
						screen_env.screen.y = setting->screen_y;
						itoSetScreenPos(setting->screen_x, setting->screen_y);
					}
				}
			}
			else if(new_pad & PAD_CIRCLE)
			{
				if(s<12) {
					if(rgb[s/3][s%3] < 255) {
						rgb[s/3][s%3]++;
						setting->color[s/3] = 
							ITO_RGBA(rgb[s/3][0], rgb[s/3][1], rgb[s/3][2], 0);
						if(s/3 == 0) itoSetBgColor(setting->color[0]);
					}
				} else if(s==12) {
					setting->screen_x++;
					screen_env.screen.x = setting->screen_x;
					itoSetScreenPos(setting->screen_x, setting->screen_y);
				} else if(s==13) {
					setting->screen_y++;
					screen_env.screen.y = setting->screen_y;
					itoSetScreenPos(setting->screen_x, setting->screen_y);
				} else if(s==14) {
					setting->interlace = !setting->interlace;
					screen_env.interlace = setting->interlace;
					itoGsReset();
					itoGsEnvSubmit(&screen_env);
				} else if(s==15) {
					return;
				} else if(s==16) {
					setting->color[0] = DEF_COLOR1;
					setting->color[1] = DEF_COLOR2;
					setting->color[2] = DEF_COLOR3;
					setting->color[3] = DEF_COLOR4;
					setting->screen_x = DEF_SCREEN_X;
					setting->screen_y = DEF_SCREEN_Y;
					setting->interlace = DEF_INTERLACE;
					screen_env.screen.x = setting->screen_x;
					screen_env.screen.y = setting->screen_y;
					screen_env.interlace = setting->interlace;
					itoGsReset();
					itoGsEnvSubmit(&screen_env);
					itoSetBgColor(setting->color[0]);
					//itoSetScreenPos(setting->screen_x, setting->screen_y);
					
					for(i=0; i<4; i++) {
						rgb[i][0] = setting->color[i] & 0xFF;
						rgb[i][1] = setting->color[i] >> 8 & 0xFF;
						rgb[i][2] = setting->color[i] >> 16 & 0xFF;
					}
				}
			}
		}
		
		// ��ʕ`��J�n
		clrScr(setting->color[0]);
		
		// �g�̒�
		x = SCREEN_MARGIN + LINE_THICKNESS + FONT_WIDTH;
		y = SCREEN_MARGIN + FONT_HEIGHT*2 + LINE_THICKNESS + 12;
		for(i=0; i<4; i++)
		{
			sprintf(c, "  COLOR%d R: %lu", i+1, rgb[i][0]);
			printXY(c, x, y/2, setting->color[3], TRUE);
			y += FONT_HEIGHT;
			sprintf(c, "  COLOR%d G: %lu", i+1, rgb[i][1]);
			printXY(c, x, y/2, setting->color[3], TRUE);
			y += FONT_HEIGHT;
			sprintf(c, "  COLOR%d B: %lu", i+1, rgb[i][2]);
			printXY(c, x, y/2, setting->color[3], TRUE);
			y += FONT_HEIGHT;
			y += FONT_HEIGHT / 2;
		}
		
		sprintf(c, "  SCREEN X: %d", setting->screen_x);
		printXY(c, x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		sprintf(c, "  SCREEN Y: %d", setting->screen_y);
		printXY(c, x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		y += FONT_HEIGHT / 2;
		
		if(setting->interlace)
			sprintf(c, "  INTERLACE: ON");
		else
			sprintf(c, "  INTERLACE: OFF");
		printXY(c, x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		y += FONT_HEIGHT / 2;
		
		printXY("  RETURN", x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		printXY("  INIT", x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		
		y = s * FONT_HEIGHT + SCREEN_MARGIN+FONT_HEIGHT*2+12+LINE_THICKNESS;
		if(s>=3) y+=FONT_HEIGHT/2;
		if(s>=6) y+=FONT_HEIGHT/2;
		if(s>=9) y+=FONT_HEIGHT/2;
		if(s>=12) y+=FONT_HEIGHT/2;
		if(s>=14) y+=FONT_HEIGHT/2;
		if(s>=15) y+=FONT_HEIGHT/2;
		drawChar(127, x, y/2, setting->color[3]);
		
		x = SCREEN_MARGIN;
		y = SCREEN_HEIGHT-SCREEN_MARGIN-FONT_HEIGHT;
		if (s <= 13) strcpy(c, "��:Add �~:Away");
		else if(s==14) strcpy(c, "��:Change");
		else strcpy(c, "��:OK");
		
		setScrTmp("", c);
		drawScr();
	}
}

////////////////////////////////////////////////////////////////////////
// Config���
void config(char *mainMsg)
{
	char c[MAX_PATH];
	int i;
	int s;
	int x, y;
	
	tmpsetting = setting;
	setting = (SETTING*)malloc(sizeof(SETTING));
	*setting = *tmpsetting;
	
	s=0;
	while(1)
	{
		// ����
		waitPadReady(0, 0);
		if(readpad())
		{
			if(new_pad & PAD_UP)
			{
				if(s!=0)
					s--;
				else
					s=CANCEL;
			}
			else if(new_pad & PAD_DOWN)
			{
				if(s!=CANCEL)
					s++;
				else
					s=0;
			}
			else if(new_pad & PAD_LEFT)
			{
				if(s>=OK)
					s=TIMEOUT;
				else
					s=DEFAULT;
			}
			else if(new_pad & PAD_RIGHT)
			{
				if(s<TIMEOUT)
					s=TIMEOUT;
				else if(s<OK)
					s=OK;
			}
			else if(new_pad & PAD_CROSS)
			{
				if(s<TIMEOUT)
					setting->dirElf[s][0]=0;
				else if(s==TIMEOUT)
				{
					if(setting->timeout > 0)
						setting->timeout--;
				}
			}
			else if(new_pad & PAD_CIRCLE)
			{
				if(s<TIMEOUT)
				{
					getFilePath(setting->dirElf[s], TRUE);
					if(!strncmp(setting->dirElf[s], "mc", 2)){
						sprintf(c, "mc%s", &setting->dirElf[s][3]);
						strcpy(setting->dirElf[s], c);
					}
				}
				else if(s==TIMEOUT)
					setting->timeout++;
				else if(s==FILENAME)
					setting->filename = !setting->filename;
				else if(s==DISCCONTROL)
					setting->discControl = !setting->discControl;
				else if(s==SCREEN)
					setColor();
				else if(s==OK)
				{
					free(tmpsetting);
					saveConfig(mainMsg);
					break;
				}
				else if(s==CANCEL)
				{
					free(setting);
					setting = tmpsetting;
					screen_env.screen.x = setting->screen_x;
					screen_env.screen.y = setting->screen_y;
					screen_env.interlace = setting->interlace;
					itoGsReset();
					itoGsEnvSubmit(&screen_env);
					itoSetBgColor(setting->color[0]);
					mainMsg[0] = 0;
					break;
				}
			}
		}
		
		// ��ʕ`��J�n
		clrScr(setting->color[0]);
		
		// �g�̒�
		x = SCREEN_MARGIN + LINE_THICKNESS + FONT_WIDTH;
		y = SCREEN_MARGIN + FONT_HEIGHT*2 + LINE_THICKNESS + 12;
		printXY("BUTTON SETTING", x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		for(i=0; i<12; i++)
		{
			switch(i)
			{
			case 0:
				strcpy(c,"  DEFAULT: ");
				break;
			case 1:
				strcpy(c,"  ��     : ");
				break;
			case 2:
				strcpy(c,"  �~     : ");
				break;
			case 3:
				strcpy(c,"  ��     : ");
				break;
			case 4:
				strcpy(c,"  ��     : ");
				break;
			case 5:
				strcpy(c,"  L1     : ");
				break;
			case 6:
				strcpy(c,"  R1     : ");
				break;
			case 7:
				strcpy(c,"  L2     : ");
				break;
			case 8:
				strcpy(c,"  R2     : ");
				break;
			case 9:
				strcpy(c,"  L3     : ");
				break;
			case 10:
				strcpy(c,"  R3     : ");
				break;
			case 11:
				strcpy(c,"  START  : ");
				break;
			}
			strcat(c, setting->dirElf[i]);
			printXY(c, x, y/2, setting->color[3], TRUE);
			y += FONT_HEIGHT;
		}
		
		y += FONT_HEIGHT / 2;
		
		printXY("MISC", x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		sprintf(c, "  TIMEOUT: %d", setting->timeout);
		printXY(c, x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		
		if(setting->discControl)
			sprintf(c, "  DISC CONTROL: ON");
		else
			sprintf(c, "  DISC CONTROL: OFF");
		printXY(c, x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		
		if(setting->filename)
			sprintf(c, "  PRINT ONLY FILENAME: ON");
		else
			sprintf(c, "  PRINT ONLY FILENAME: OFF");
		printXY(c, x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		
		printXY("  SCREEN SETTING", x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		y += FONT_HEIGHT / 2;
		printXY("  OK", x, y/2, setting->color[3], TRUE);
		y += FONT_HEIGHT;
		printXY("  CANCEL", x, y/2, setting->color[3], TRUE);
		
		y = s * FONT_HEIGHT + SCREEN_MARGIN+FONT_HEIGHT*3+12+LINE_THICKNESS;
		if(s>=TIMEOUT)
			y += FONT_HEIGHT + FONT_HEIGHT / 2;
		if(s>=OK)
			y += FONT_HEIGHT / 2;
		drawChar(127, x, y/2, setting->color[3]);
		
		if (s < TIMEOUT) sprintf(c, "��:Edit �~:Clear");
		else if(s==TIMEOUT) sprintf(c, "��:Add �~:Away");
		else if(s==FILENAME) sprintf(c, "��:Change");
		else if(s==DISCCONTROL) sprintf(c, "��:Change");
		else sprintf(c, "��:OK");
		
		setScrTmp("", c);
		drawScr();
	}
	
	return;
}
